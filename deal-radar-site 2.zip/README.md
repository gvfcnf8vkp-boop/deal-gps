# Deal Radar — sito statico

Questa cartella contiene il sito statico Deal Radar, pensato per essere pubblicato su GitHub Pages.

## Funzioni
- Creazione cartelle e filtri di ricerca
- Inserimento e gestione annunci
- Calcolo stimato di profitto e ROI
- Verdetti con controllo dei dati insufficienti
- Esportazione CSV e backup JSON

## Limiti
- Non è collegato a Vinted e non monitora automaticamente nuovi annunci.
- Le stime dipendono dai dati inseriti manualmente.
- I dati vengono salvati nel browser del dispositivo; non sono sincronizzati fra dispositivi.
- Non inserire informazioni sensibili: il sito è una demo lato client.

## Pubblicazione con GitHub Pages
1. Crea o accedi a un account GitHub.
2. Crea un nuovo repository pubblico, ad esempio `deal-radar`.
3. Carica `index.html`, `.nojekyll` e questo `README.md` nella cartella principale del repository.
4. Nel repository vai su **Settings → Pages**.
5. In **Build and deployment**, seleziona **Deploy from a branch**.
6. Scegli il branch `main` e la cartella `/ (root)`, poi premi **Save**.
7. Attendi che GitHub Pages pubblichi il sito; l'indirizzo apparirà nella sezione Pages.

Attenzione: un sito GitHub Pages è pubblico. Non caricare dati personali o credenziali nel repository.
